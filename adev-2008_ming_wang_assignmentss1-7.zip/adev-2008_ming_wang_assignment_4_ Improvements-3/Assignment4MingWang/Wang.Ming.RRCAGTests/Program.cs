﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 4
 * Created: 2023-10-15
 * Updated: 2023-10-22
 */

using System;
using Wang.Ming.Business;

class Program
{
    static void Main(string[] args)
    {
        // Construct an instance of SalesQuote class
        SalesQuote salesQuote = new SalesQuote(50000, 2000, 0.1M, Accessories.StereoSystem, ExteriorFinish.Standard);

        // Subscribe to events for salesQuote
        salesQuote.VehiclePriceChanged += SalesQuote_VehiclePriceChanged;
        salesQuote.TradeInAmountChanged += SalesQuote_TradeInAmountChanged;
        salesQuote.AccessoriesChosenChanged += SalesQuote_AccessoriesChosenChanged;
        salesQuote.ExteriorFinishChosenChanged += SalesQuote_ExteriorFinishChosenChanged;

        // Modify properties to trigger events
        Console.WriteLine("Setting vehicle sale price to 52000...");
        salesQuote.VehicleSalePrice = 52000;

        Console.WriteLine("Setting trade-in amount to 2500...");
        salesQuote.TradeInAmount = 2500;

        Console.WriteLine("Setting Accessories to StereoAndNavigation...");
        salesQuote.AccessoriesChosen = Accessories.StereoAndNavigation;

        Console.WriteLine("Setting Exterior Finish to Pearlized...");
        salesQuote.ExteriorFinishChosen = ExteriorFinish.Pearlized;


        // Construct an instance of the modified Invoice class
        CarWashInvoice invoice = new CarWashInvoice(0.05M, 0.10M);

        // Subscribe to events for invoice class
        invoice.ProvincialSalesTaxRateChanged += Invoice_ProvincialSalesTaxRateChanged;
        invoice.GoodsAndServicesTaxRateChanged += Invoice_GoodsAndServicesTaxRateChanged;

        // Modify properties to trigger events
        Console.WriteLine("Setting Provincial Sales Tax Rate to 0.06...");
        invoice.ProvincialSalesTaxRate = 0.06M;

        Console.WriteLine("Setting Goods and Services Tax Rate to 0.11...");
        invoice.GoodsAndServicesTaxRate = 0.11M;

        CarWashInvoice carWashInvoice = new CarWashInvoice(0.05M, 0.10M, 25.0M, 5.0M);


        // Subscribe to events for carWashInvoice class
        carWashInvoice.PackageCostChanged += CarWashInvoice_PackageCostChanged;
        carWashInvoice.FragranceCostChanged += CarWashInvoice_FragranceCostChanged;

        // Modify properties to trigger events
        Console.WriteLine("Setting Car Wash Package Cost to 30.0...");
        carWashInvoice.PackageCost = 30.0M;

        Console.WriteLine("Setting Fragrance Cost to 7.0...");
        carWashInvoice.FragranceCost = 7.0M;

        Console.WriteLine("Press any key to continue...");
        Console.ReadKey();
    }

    private static void SalesQuote_VehiclePriceChanged(object sender, EventArgs e)
    {
        Console.WriteLine("Vehicle price has changed!\n");
    }

    private static void SalesQuote_TradeInAmountChanged(object sender, EventArgs e)
    {
        Console.WriteLine("Trade-in amount has changed!\n");
    }

    private static void SalesQuote_AccessoriesChosenChanged(object sender, EventArgs e)
    {
        Console.WriteLine("Accessories chosen has changed!\n");
    }

    private static void SalesQuote_ExteriorFinishChosenChanged(object sender, EventArgs e)
    {
        Console.WriteLine("Exterior finish chosen has changed!\n");
    }

    private static void Invoice_ProvincialSalesTaxRateChanged(object sender, EventArgs e)
    {
        Console.WriteLine("Provincial Sales Tax Rate has changed!\n");
    }

    private static void Invoice_GoodsAndServicesTaxRateChanged(object sender, EventArgs e)
    {
        Console.WriteLine("Goods and Services Tax Rate has changed!\n");
    }

    private static void CarWashInvoice_PackageCostChanged(object sender, EventArgs e)
    {
        Console.WriteLine("Car Wash Package Cost has changed!\n");
    }

    private static void CarWashInvoice_FragranceCostChanged(object sender, EventArgs e)
    {
        Console.WriteLine("Fragrance Cost has changed!\n");
    }
}
