﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 4
 * Created: 2023-10-15
 * Updated: 2023-11-02
 */

using System;

namespace Wang.Ming.Business
{
    /// <summary>
    /// Provides financial-related utility methods.
    /// </summary>
    public static class Financial
    {
        /// <summary>
        /// Calculates the periodic payment for an annuity based on constant-amount periodic payments and a constant interest rate.
        /// </summary>
        /// <param name="rate">The interest rate for the period (must be between 0 and 1).</param>
        /// <param name="numberOfPaymentPeriods">Total number of payment periods in an annuity.</param>
        /// <param name="presentValue">The present value, or principal amount of an annuity.</param>
        /// <returns>The calculated periodic payment amount rounded to 2 decimal places.</returns>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when:
        /// - The rate is less than 0 or greater than 1.
        /// - The number of payment periods is less than or equal to 0.
        /// - The present value is less than or equal to 0.
        /// </exception>
        public static decimal GetPayment(decimal rate, int numberOfPaymentPeriods, decimal presentValue)
        {
            if (rate < 0)
                throw new ArgumentOutOfRangeException("rate", "The argument cannot be less than 0.");
            if (rate > 1)

                throw new ArgumentOutOfRangeException("rate", "The argument cannot be greater than 1.");

            if (numberOfPaymentPeriods <= 0)
                throw new ArgumentOutOfRangeException("numberOfPaymentPeriods", "The argument cannot be less than or equal to 0.");

            if (presentValue <= 0)
                throw new ArgumentOutOfRangeException("presentValue", "The argument cannot be less than or equal to 0.");

            decimal futureValue = 0;
            decimal type = 0;
            decimal payment = 0;

            if (rate == 0)
                payment = presentValue / numberOfPaymentPeriods;
            else
                payment = rate * (futureValue + presentValue * (decimal)Math.Pow((double)(1 + rate), 
                          (double)numberOfPaymentPeriods)) / (((decimal)Math.Pow((double)(1 + rate), 
                          (double)numberOfPaymentPeriods) - 1) * (1 + rate * type));

            return Math.Round(payment, 2);
        }
    }
}

