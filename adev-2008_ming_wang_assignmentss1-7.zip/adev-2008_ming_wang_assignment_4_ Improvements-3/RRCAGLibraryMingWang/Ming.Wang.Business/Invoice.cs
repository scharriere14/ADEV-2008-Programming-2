﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 4
 * Created: 2023-10-15
 * Updated: 2023-11-02
 */

using System;

namespace Wang.Ming.Business
{

    public abstract class Invoice
    {
        private decimal provincialSalesTaxRate;
        private decimal goodsAndServicesTaxRate;

        /// <summary>
        /// Occurs when the provincial sales tax rate of the Invoice changes.
        /// </summary>
        public event EventHandler ProvincialSalesTaxRateChanged;

        /// <summary>
        /// Occurs when the goods and services tax rate of the Invoice changes.
        /// </summary>
        public event EventHandler GoodsAndServicesTaxRateChanged;

        /// <summary>
        /// Raises the <see cref="ProvincialSalesTaxRateChanged"/> event.
        /// </summary>>
        protected virtual void OnProvincialSalesTaxRateChanged()
        {
            if (ProvincialSalesTaxRateChanged != null)
            {
                ProvincialSalesTaxRateChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Raises the <see cref="GoodsAndServicesTaxRateChanged"/> event.
        /// </summary>
        protected virtual void OnGoodsAndServicesTaxRateChanged()
        {
            if (GoodsAndServicesTaxRateChanged != null)
            {
                GoodsAndServicesTaxRateChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Gets or sets the provincial sales tax rate. 
        /// Value must be between 0 and 1.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the value is set to less than 0 or greater than 1.
        /// </exception>
        public decimal ProvincialSalesTaxRate
        {
            get { return provincialSalesTaxRate; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                if (value > 1)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be greater than 1.");
                }
                if (value != provincialSalesTaxRate)
                {
                    provincialSalesTaxRate = value;
                    OnProvincialSalesTaxRateChanged();
                }
            }
        }

        /// <summary>
        /// Gets or sets the goods and services tax rate. 
        /// Value must be between 0 and 1.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the value is set to less than 0 or greater than 1.
        /// </exception>
        public decimal GoodsAndServicesTaxRate
        {
            get { return goodsAndServicesTaxRate; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                if (value > 1)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be greater than 1.");
                }
                if (value != goodsAndServicesTaxRate)
                {
                    goodsAndServicesTaxRate = value;
                    OnGoodsAndServicesTaxRateChanged();
                }
            }
        }

        /// <summary>
        /// Gets the provincial sales tax charged. This is a stub in the base class.
        /// </summary>
        public abstract decimal ProvincialSalesTaxCharged
        {
            get;
        }

        /// <summary>
        /// Gets the goods and services tax charged. This is a stub in the base class.
        /// </summary>
        public abstract decimal GoodsAndServicesTaxCharged
        {
            get;
        }

        /// <summary>
        /// Gets the subtotal of the invoice. This is a stub in the base class.
        /// </summary>
        public abstract decimal SubTotal
        {
            get;
        }

        /// <summary>
        /// Gets the total invoice amount including applicable taxes.
        /// </summary>
        public decimal Total
        {
            get
            {
                return Math.Round(SubTotal + ProvincialSalesTaxCharged + GoodsAndServicesTaxCharged, 2);
            }
        }

        /// <summary>
        /// Initializes a new instance of the Invoice class with the specified tax rates.
        /// </summary>
        /// <param name="provincialSalesTaxRate">The rate of provincial sales tax.</param>
        /// <param name="goodsAndServicesTaxRate">The rate of goods and services tax.</param>
        public Invoice(decimal provincialSalesTaxRate, decimal goodsAndServicesTaxRate)
        {
            this.provincialSalesTaxRate = provincialSalesTaxRate;
            this.goodsAndServicesTaxRate = goodsAndServicesTaxRate;
        }
    }
}
