﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 2
 * Created: 2023-09-11
 * Updated: 2023-10-06
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Wang.Ming.Business;

class Program
{
    static void Main()
    {
        Console.WriteLine("Testing method GetPayment(decimal, int, decimal)\n");

        Console.WriteLine("\nTest 1: Rate is zero");
        GetPayment_RateZero_Payment();

        Console.WriteLine("\nTest 2: Rate is above zero");
        GetPayment_RateAboveZero_Payment();

        Console.WriteLine("\nTest 3: Rate is below zero");
        GetPayment_RateBelowZero_Exception();

        Console.WriteLine("\nTest 4: Rate is above one");
        GetPayment_RateAboveOne_Exception();

        Console.WriteLine("\nTest 5: Number of payments is below zero");
        GetPayment_NumberOfPaymentsBelowZero_Exception();

        Console.WriteLine("\nTest 6: Number of payments is zero");
        GetPayment_NumberOfPaymentsZero_Exception();

        Console.WriteLine("\nTest 7: Present value is below zero");
        GetPayment_PresentValueBelowZero_Exception();

        Console.WriteLine("\nTest 8: Present value is zero");
        GetPayment_PresentValueZero_Exception();

        Console.WriteLine("\nPress any key to continue...");
        Console.ReadKey();
    }

    static void GetPayment_RateZero_Payment()
    {
        decimal rate = 0M;
        int numberOfPayments = 12;
        decimal presentValue = 6000M;

        try
        {
            decimal payment = Financial.GetPayment(rate, numberOfPayments, presentValue);
            Console.WriteLine("Expected: 500.00");
            Console.WriteLine($"Actual: {payment:C2}");
        }
        catch (Exception e)
        {
            Console.WriteLine($"Unexpected exception: {e.Message}");
        }
    }

    static void GetPayment_RateAboveZero_Payment()
    {
        decimal rate = 0.05M;
        int numberOfPayments = 12;
        decimal presentValue = 5000M;

        try
        {
            decimal payment = Financial.GetPayment(rate, numberOfPayments, presentValue);
            Console.WriteLine("Expected: 564.13");
            Console.WriteLine($"Actual: {payment:C2}");
        }
        catch (Exception e)
        {
            Console.WriteLine($"Unexpected exception: {e.Message}");
        }
    }

    static void GetPayment_RateBelowZero_Exception()
    {
        decimal rate = -0.05M;
        int numberOfPayments = 12;
        decimal presentValue = 5000M;

        try
        {
            decimal payment = Financial.GetPayment(rate, numberOfPayments, presentValue);
        }
        catch (ArgumentOutOfRangeException e)
        {
            string expected = "The argument cannot be less than 0.\nParameter name: rate";
            string actual = e.Message;
            Console.WriteLine($"Expected: {expected}");
            Console.WriteLine($"Actual: {actual}");
        }
    }

    static void GetPayment_RateAboveOne_Exception()
    {
        decimal rate = 1.05M;
        int numberOfPayments = 12;
        decimal presentValue = 5000M;

        try
        {
            decimal payment = Financial.GetPayment(rate, numberOfPayments, presentValue);
        }
        catch (ArgumentOutOfRangeException e)
        {
            string expected = "The argument cannot be greater than 1.\nParameter name: rate";
            string actual = e.Message;
            Console.WriteLine($"Expected: {expected}");
            Console.WriteLine($"Actual: {actual}");
        }
    }

    static void GetPayment_NumberOfPaymentsBelowZero_Exception()
    {
        decimal rate = 0.5M;
        int numberOfPayments = -5;
        decimal presentValue = 10000M;

        try
        {
            decimal payment = Financial.GetPayment(rate, numberOfPayments, presentValue);
        }
        catch (ArgumentOutOfRangeException e)
        {
            string expected = "The argument cannot be less than or equal to 0.\nParameter name: numberOfPaymentPeriods";
            string actual = e.Message;
            Console.WriteLine($"Expected: {expected}");
            Console.WriteLine($"Actual: {actual}");
        }
    }

    static void GetPayment_NumberOfPaymentsZero_Exception()
    {
        decimal rate = 0.5M;
        int numberOfPayments = 0;
        decimal presentValue = 10000M;

        try
        {
            decimal payment = Financial.GetPayment(rate, numberOfPayments, presentValue);
        }
        catch (ArgumentOutOfRangeException e)
        {
            string expected = "The argument cannot be less than or equal to 0.\nParameter name: numberOfPaymentPeriods";
            string actual = e.Message;
            Console.WriteLine($"Expected: {expected}");
            Console.WriteLine($"Actual: {actual}");
        }
    }

    static void GetPayment_PresentValueBelowZero_Exception()
    {
        decimal rate = 0.5M;
        int numberOfPayments = 12;
        decimal presentValue = -10000M;

        try
        {
            decimal payment = Financial.GetPayment(rate, numberOfPayments, presentValue);
        }
        catch (ArgumentOutOfRangeException e)
        {
            string expected = "The argument cannot be less than or equal to 0.\nParameter name: presentValue";
            string actual = e.Message;
            Console.WriteLine($"Expected: {expected}");
            Console.WriteLine($"Actual: {actual}");
        }
    }

    static void GetPayment_PresentValueZero_Exception()
    {
        decimal rate = 0.5M;
        int numberOfPayments = 12;
        decimal presentValue = 0M;

        try
        {
            decimal payment = Financial.GetPayment(rate, numberOfPayments, presentValue);
        }
        catch (ArgumentOutOfRangeException e)
        {
            string expected = "The argument cannot be less than or equal to 0.\nParameter name: presentValue";
            string actual = e.Message;
            Console.WriteLine($"Expected: {expected}");
            Console.WriteLine($"Actual: {actual}");
        }
    }
}

