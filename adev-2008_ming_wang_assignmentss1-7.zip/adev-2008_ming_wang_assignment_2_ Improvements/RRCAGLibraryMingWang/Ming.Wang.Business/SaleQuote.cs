﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 2
 * Created: 2023-09-11
 * Updated: 2023-10-06
 */

using System;
using System.ComponentModel;

namespace Wang.Ming.Business
{
    /// <summary>
    /// Represents a sales quotation for a vehicle, including its price, accessories, and exterior finish.
    /// </summary>
    public class SalesQuote
    {
        private decimal vehicleSalePrice;
        private decimal tradeInAmount;
        private decimal salesTaxRate;
        private Accessories accessoriesChosen;
        private ExteriorFinish exteriorFinishChosen;

        /// <summary>
        /// Gets or sets the sale price of the vehicle.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the value is less than or equal to 0.
        /// </exception>
        public decimal VehicleSalePrice
        {
            get
            { 
                return vehicleSalePrice; 
            }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than or equal to 0.");
                }
                vehicleSalePrice = value;
            }
        }

        /// <summary>
        /// Gets or sets the trade-in amount for the vehicle.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the value is less than 0.
        /// </exception>
        public decimal TradeInAmount
        {
            get
            {
                return tradeInAmount; 
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                tradeInAmount = value;
            }
        }

        /// <summary>
        /// Gets or sets the accessories chosen for the vehicle.
        /// </summary>
        /// <exception cref="InvalidEnumArgumentException">
        /// Thrown when the value is not a valid <see cref="Accessories"/> enumeration value.
        /// </exception>
        public Accessories AccessoriesChosen
        {
            get
            {
                return accessoriesChosen; 
            }
            set
            {
                if (!Enum.IsDefined(typeof(Accessories), value))
                {
                    throw new InvalidEnumArgumentException("The value is an invalid enumeration value");
                }
                accessoriesChosen = value;
            }
        }

        /// <summary>
        /// Gets or sets the exterior finish chosen for the vehicle.
        /// </summary>
        /// <exception cref="InvalidEnumArgumentException">
        /// Thrown when the value is not a valid <see cref="ExteriorFinish"/> enumeration value.
        /// </exception>
        public ExteriorFinish ExteriorFinishChosen
        {
            get
            {
               return exteriorFinishChosen; 
            }
            set
            {
                if (!Enum.IsDefined(typeof(ExteriorFinish), value))
                {
                    throw new InvalidEnumArgumentException("The value is an invalid enumeration value");
                }
                exteriorFinishChosen = value;
            }
        }

        /// <summary>
        /// Gets the cost of the chosen accessories for the vehicle.
        /// </summary>
        public decimal AccessoryCost
        {
            get
            {
                return GetAccessoryCost(); 
            } 
        }

        /// <summary>
        /// Gets the cost of the chosen exterior finish for the vehicle.
        /// </summary>
        public decimal FinishCost
        {
            get
            {
                return GetFinishCost(); 
            }
        }

        /// <summary>
        /// Gets the total cost of options chosen for the vehicle.
        /// </summary>
        public decimal TotalOptions
        {
            get
            {
                return Math.Round(AccessoryCost + FinishCost, 2); 
            }
        }

        /// <summary>
        /// Gets the subtotal amount for the vehicle sale.
        /// </summary>
        public decimal SubTotal
        { 
            get
            { 
                return Math.Round(VehicleSalePrice + TotalOptions, 2); 
            } 
        }

        /// <summary>
        /// Gets the sales tax amount for the vehicle sale.
        /// </summary>
        public decimal SalesTax
        {
            get
            {
                return Math.Round(SubTotal * salesTaxRate, 2); 
            }
        }

        /// <summary>
        /// Gets the total amount due for the vehicle sale.
        /// </summary>
        public decimal Total
        {
            get
            {
                return SubTotal + SalesTax;
            }
        }

        /// <summary>
        /// Gets the amount due after considering the trade-in amount.
        /// </summary>
        public decimal AmountDue
        {
            get
            {
                return Math.Round(Total - TradeInAmount, 2); 
            } 
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SalesQuote"/> class with specific details.
        /// </summary>
        /// <param name="vehicleSalePrice">The sale price of the vehicle.</param>
        /// <param name="tradeInAmount">The trade-in amount for the vehicle.</param>
        /// <param name="salesTaxRate">The sales tax rate applicable to the sale.</param>
        /// <param name="accessoriesChosen">The accessories chosen for the vehicle.</param>
        /// <param name="exteriorFinishChosen">The exterior finish chosen for the vehicle.</param>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate, Accessories accessoriesChosen, ExteriorFinish exteriorFinishChosen)
        {
            ValidateInputs(vehicleSalePrice, tradeInAmount, salesTaxRate);

            VehicleSalePrice = vehicleSalePrice;
            TradeInAmount = tradeInAmount;
            this.salesTaxRate = salesTaxRate;
            AccessoriesChosen = accessoriesChosen;
            ExteriorFinishChosen = exteriorFinishChosen;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SalesQuote"/> class with default accessory and finish options.
        /// </summary>
        /// <param name="vehicleSalePrice">The sale price of the vehicle.</param>
        /// <param name="tradeInAmount">The trade-in amount for the vehicle.</param>
        /// <param name="salesTaxRate">The sales tax rate applicable to the sale.</param>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate)
        {
            ValidateInputs(vehicleSalePrice, tradeInAmount, salesTaxRate);

            VehicleSalePrice = vehicleSalePrice;
            TradeInAmount = tradeInAmount;
            this.salesTaxRate = salesTaxRate;
            AccessoriesChosen = Accessories.None;
            ExteriorFinishChosen = ExteriorFinish.None;
        }

        /// <summary>
        /// Validates the provided inputs for constructing a <see cref="SalesQuote"/>.
        /// </summary>
        /// <param name="vehicleSalePrice">The sale price of the vehicle.</param>
        /// <param name="tradeInAmount">The trade-in amount for the vehicle.</param>
        /// <param name="salesTaxRate">The sales tax rate applicable to the sale.</param>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the vehicle sale price is less than or equal to 0, 
        /// the trade-in amount is less than 0, or 
        /// the sales tax rate is less than 0 or greater than 1.
        /// </exception>
        private void ValidateInputs(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate)
        {
        }


        /// <summary>
        /// Returns the cost of the chosen accessories.
        /// </summary>
        /// <returns>The cost of the chosen accessories.</returns>
        public decimal GetAccessoryCost()
        {
            decimal accessoriesCost = 0;
            decimal stereoSystem = 505.05M;
            decimal leatherInterior = 1010.10M;
            decimal computerNavigation = 1515.15M;

            switch (accessoriesChosen)
            {
                case Accessories.StereoSystem:
                    accessoriesCost = stereoSystem;
                    break;
                case Accessories.LeatherInterior:
                    accessoriesCost = leatherInterior;
                    break;
                case Accessories.ComputerNavigation:
                    accessoriesCost = computerNavigation;
                    break;
                case Accessories.StereoAndLeather:
                    accessoriesCost = stereoSystem + leatherInterior;
                    break;
                case Accessories.StereoAndNavigation:
                    accessoriesCost = stereoSystem + computerNavigation;
                    break;
                case Accessories.LeatherAndNavigation:
                    accessoriesCost = leatherInterior + computerNavigation;
                    break;
                case Accessories.All:
                    accessoriesCost = stereoSystem + leatherInterior + computerNavigation;
                    break;
                case Accessories.None:
                    accessoriesCost = 0;
                    break;
            }
            return accessoriesCost;
        }

        /// <summary>
        /// Returns the cost of the chosen exterior finish.
        /// </summary>
        /// <returns>The cost of the chosen exterior finish.</returns>
        public decimal GetFinishCost()
        {
            switch (exteriorFinishChosen)
            {
                case ExteriorFinish.Standard:
                    return 202.02M;
                case ExteriorFinish.Pearlized:
                    return 404.04M;
                case ExteriorFinish.Custom:
                    return 606.06M;
                default:
                    return 0M;
            }
        }
    }
}



