﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 2
 * Created: 2023-09-11
 * Updated: 2023-10-06
 */

using System;

namespace Wang.Ming.Business
{
    /// <summary>
    /// Represents an abstract invoice that contains the functionalities to support the business process of creating an invoice.
    /// </summary>
    public abstract class Invoice
    {
        // Private fields to hold the tax rates applied to the invoice.
        private decimal provincialSalesTaxRate;
        private decimal goodsAndServicesTaxRate;

        /// <summary>
        /// Gets or sets the provincial sales tax rate applied to the invoice.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the value set is less than 0 or greater than 1.
        /// </exception>
        public decimal ProvincialSalesTaxRate
        {
            get { return provincialSalesTaxRate; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                if (value > 1)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be greater than 1.");
                }
                provincialSalesTaxRate = value;
            }
        }

        /// <summary>
        /// Gets or sets the goods and services tax rate applied to the invoice.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the value set is less than 0 or greater than 1.
        /// </exception>
        public decimal GoodsAndServicesTaxRate
        {
            get { return goodsAndServicesTaxRate; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                if (value > 1)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be greater than 1.");
                }
                goodsAndServicesTaxRate = value;
            }
        }

        /// <summary>
        /// Gets the amount of provincial sales tax charged, rounded to two decimal places.
        /// </summary>
        public abstract decimal ProvincialSalesTaxCharged { get; }

        /// <summary>
        /// Gets the amount of goods and services tax charged, rounded to two decimal places.
        /// </summary>
        public abstract decimal GoodsAndServicesTaxCharged { get; }

        /// <summary>
        /// Gets the subtotal of the invoice.
        /// </summary>
        public abstract decimal SubTotal { get; }

        /// <summary>
        /// Gets the total of the invoice, calculated as the sum of the subtotal and both taxes, rounded to two decimal places.
        /// </summary>
        public decimal Total
        {
            get { return Math.Round(SubTotal + ProvincialSalesTaxCharged + GoodsAndServicesTaxCharged, 2); }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Invoice"/> class with specified provincial and goods and services tax rates.
        /// </summary>
        /// <param name="provincialSalesTaxRate">The rate of provincial tax charged to a customer.</param>
        /// <param name="goodsAndServicesTaxRate">The rate of goods and services tax charged to a customer.</param>
        public Invoice(decimal provincialSalesTaxRate, decimal goodsAndServicesTaxRate)
        {
            this.provincialSalesTaxRate = provincialSalesTaxRate;
            this.goodsAndServicesTaxRate = goodsAndServicesTaxRate;
        }

    }
}



