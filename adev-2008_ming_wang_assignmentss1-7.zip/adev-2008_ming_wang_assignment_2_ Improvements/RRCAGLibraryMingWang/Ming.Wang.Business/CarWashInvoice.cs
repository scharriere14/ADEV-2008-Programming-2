﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 2
 * Created: 2023-09-11
 * Updated: 2023-10-06
 */

using System;

namespace Wang.Ming.Business
{
    /// <summary>
    /// Represents an invoice for car wash services, including details on package and fragrance costs, as well as tax information.
    /// </summary>
    public class CarWashInvoice : Invoice
    {
        private decimal packageCost;
        private decimal fragranceCost;

        /// <summary>
        /// Gets or sets the cost of the car wash package.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when the value is set to less than 0.</exception>
        public decimal PackageCost
        {
            get { return packageCost; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                packageCost = value;
            }
        }
        /// <summary>
        /// Gets or sets the cost of the fragrance service.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when the value is set to less than 0.</exception>
        public decimal FragranceCost
        {
            get { return fragranceCost; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                fragranceCost = value;
            }
        }

        /// <summary>
        /// Gets the provincial sales tax charged, which is always 0 for car wash services.
        /// </summary>
        public override decimal ProvincialSalesTaxCharged
        {
            get { return 0M; }
        }

        /// <summary>
        /// Gets the goods and services tax charged, calculated as the goods and services tax rate multiplied by the subtotal, rounded to 2 decimal places.
        /// </summary>
        public override decimal GoodsAndServicesTaxCharged
        {
            get { return Math.Round(GoodsAndServicesTaxRate * SubTotal, 2); }
        }

        /// <summary>
        /// Gets the subtotal of the invoice, calculated as the sum of the package cost and the fragrance cost.
        /// </summary>
        public override decimal SubTotal
        {
            get { return PackageCost + FragranceCost; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CarWashInvoice"/> class with specified tax rates and zeroed package and fragrance costs.
        /// </summary>
        /// <param name="provincialSalesTaxRate">The rate of provincial sales tax.</param>
        /// <param name="goodsAndServicesTaxRate">The rate of goods and services tax.</param>
        public CarWashInvoice(decimal provincialSalesTaxRate, decimal goodsAndServicesTaxRate)
            : base(provincialSalesTaxRate, goodsAndServicesTaxRate)
        {
            packageCost = 0M;
            fragranceCost = 0M;
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="CarWashInvoice"/> class with specified provincial and goods and services tax rates, package cost, and fragrance cost.
        /// </summary>
        /// <param name="provincialSalesTaxRate">The rate of provincial sales tax.</param>
        /// <param name="goodsAndServicesTaxRate">The rate of goods and services tax.</param>
        /// <param name="packageCost">The cost of the chosen package.</param>
        /// <param name="fragranceCost">The cost of the chosen fragrance.</param>
        public CarWashInvoice(decimal provincialSalesTaxRate, decimal goodsAndServicesTaxRate, decimal packageCost, decimal fragranceCost)
            : base(provincialSalesTaxRate, goodsAndServicesTaxRate)
        {
            PackageCost = packageCost;
            FragranceCost = fragranceCost;
        }

    }
}

