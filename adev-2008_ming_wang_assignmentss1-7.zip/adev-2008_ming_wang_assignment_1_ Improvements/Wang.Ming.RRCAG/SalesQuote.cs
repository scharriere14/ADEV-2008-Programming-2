﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 1
 * Created: 2023-09-02
 * Updated: 2023-09-21
 */

using System;

namespace Wang.Ming.Business
{
    /// <summary>
    /// Represents a quote for the sale of a vehicle.
    /// </summary>
    public class SalesQuote
    {
        private decimal vehicleSalePrice;
        private decimal tradeInAmount;
        private decimal salesTaxRate;
        private Accessories accessoriesChosen;
        private ExteriorFinish exteriorFinishChosen;

        /// <summary>
        /// Initializes an instance of SalesQuote with all parameters including accessories and exterior finish.
        /// </summary>
        /// <param name="vehicleSalePrice">The selling price of the vehicle.</param>
        /// <param name="tradeInAmount">The amount for the trade-in.</param>
        /// <param name="salesTaxRate">The sales tax rate.</param>
        /// <param name="accessoriesChosen">The chosen accessories.</param>
        /// <param name="exteriorFinishChosen">The chosen exterior finish.</param>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate, 
                          Accessories accessoriesChosen, ExteriorFinish exteriorFinishChosen)
        {
            this.vehicleSalePrice = vehicleSalePrice;
            this.tradeInAmount = tradeInAmount;
            this.salesTaxRate = salesTaxRate;
            this.accessoriesChosen = accessoriesChosen;
            this.exteriorFinishChosen = exteriorFinishChosen;
        }

        /// <summary>
        /// Initializes an instance of SalesQuote with only vehicle price, trade-in amount, and sales tax rate.
        /// Accessories and exterior finish are set to default values.
        /// </summary>
        /// <param name="vehicleSalePrice">The selling price of the vehicle.</param>
        /// <param name="tradeInAmount">The amount for the trade-in.</param>
        /// <param name="salesTaxRate">The sales tax rate.</param>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate)
            : this(vehicleSalePrice, tradeInAmount, salesTaxRate, Accessories.None, ExteriorFinish.None)
        {
        }

        /// <summary>
        /// Gets the sale price of the vehicle.
        /// </summary>
        /// <returns>The sale price of the vehicle.</returns>
        public decimal GetVehicleSalePrice()
        {
            return this.vehicleSalePrice;
        }

        /// <summary>
        /// Sets the sale price of the vehicle.
        /// </summary>
        /// <param name="vehicleSalePrice">The selling price of the vehicle.</param>
        public void SetVehicleSalePrice(decimal vehicleSalePrice)
        {
            this.vehicleSalePrice = vehicleSalePrice;
        }

        /// <summary>
        /// Gets the trade-in amount.
        /// </summary>
        /// <returns>The trade-in amount.</returns>
        public decimal GetTradeInAmount()
        {
            return this.tradeInAmount;
        }

        /// <summary>
        /// Sets the trade-in amount.
        /// </summary>
        /// <param name="tradeInAmount">The amount for the trade-in.</param>
        public void SetTradeInAmount(decimal tradeInAmount)
        {
            this.tradeInAmount = tradeInAmount;
        }

        /// <summary>
        /// Gets the chosen accessories.
        /// </summary>
        /// <returns>The chosen accessories.</returns>
        public Accessories GetAccessoriesChosen()
        {
            return this.accessoriesChosen;
        }

        /// <summary>
        /// Sets the chosen accessories.
        /// </summary>
        /// <param name="accessoriesChosen">The chosen accessories.</param>
        public void SetAccessoriesChosen(Accessories accessoriesChosen)
        {
            this.accessoriesChosen = accessoriesChosen;
        }

        /// <summary>
        /// Gets the chosen exterior finish.
        /// </summary>
        /// <returns>The chosen exterior finish.</returns>
        public ExteriorFinish GetExteriorFinishChosen()
        {
            return this.exteriorFinishChosen;
        }

        /// <summary>
        /// Sets the chosen exterior finish.
        /// </summary>
        /// <param name="exteriorFinishChosen">The chosen exterior finish.</param>
        public void SetExteriorFinishChosen(ExteriorFinish exteriorFinishChosen)
        {
            this.exteriorFinishChosen = exteriorFinishChosen;
        }

        /// <summary>
        /// Returns the cost of the chosen accessories.
        /// </summary>
        /// <returns>The cost of the chosen accessories.</returns>
        public decimal GetAccessoriesCost()
        {
            decimal accessoriesCost = 0;
            decimal stereoSystem = 505.05M;
            decimal leatherInterior = 1010.10M;
            decimal computerNavigation = 1515.15M;

            switch (accessoriesChosen)
            {
                case Accessories.StereoSystem:
                    accessoriesCost = stereoSystem;
                    break;
                case Accessories.LeatherInterior:
                    accessoriesCost = leatherInterior;
                    break;
                case Accessories.ComputerNavigation:
                    accessoriesCost = computerNavigation;
                    break;
                case Accessories.StereoAndLeather:
                    accessoriesCost = stereoSystem + leatherInterior;
                    break;
                case Accessories.StereoAndNavigation:
                    accessoriesCost = stereoSystem + computerNavigation;
                    break;
                case Accessories.LeatherAndNavigation:
                    accessoriesCost = leatherInterior + computerNavigation;
                    break;
                case Accessories.All:
                    accessoriesCost = stereoSystem + leatherInterior + computerNavigation;
                    break;
                case Accessories.None:
                    accessoriesCost = 0;
                    break;
            }
            return accessoriesCost;
        }

        /// <summary>
        /// Returns the cost of the chosen exterior finish.
        /// </summary>
        /// <returns>The cost of the chosen exterior finish.</returns>
        public decimal GetExteriorFinishCost()
        {
            switch (exteriorFinishChosen)
            {
                case ExteriorFinish.Standard:
                    return 202.02M;
                case ExteriorFinish.Pearlized:
                    return 404.04M;
                case ExteriorFinish.Custom:
                    return 606.06M;
                default:
                    return 0M;
            }
        }

        /// <summary>
        /// Returns the sum of the cost of accessories chosen and the cost of the exterior finish chosen.
        /// </summary>
        /// <returns>The total options cost.</returns>
        public decimal GetTotalOptions()
        {
            return GetAccessoriesCost() + GetExteriorFinishCost();
        }

        /// <summary>
        /// Returns the subtotal.
        /// </summary>
        /// <returns>The subtotal amount.</returns>
        public decimal GetSubTotal()
        {
            return Math.Round(vehicleSalePrice + GetTotalOptions(), 2);
        }


        /// <summary>
        /// Returns the sales tax amount.
        /// </summary>
        /// <returns>The sales tax amount.</returns>
        public decimal GetSalesTax()
        {
            return Math.Round(GetSubTotal() * salesTaxRate, 2);
        }

        /// <summary>
        /// Returns the total cost.
        /// </summary>
        /// <returns>The total cost.</returns>
        public decimal GetTotal()
        {
            return GetSubTotal() + GetSalesTax();
        }

        /// <summary>
        /// Returns the amount due after considering the trade-in amount.
        /// </summary>
        /// <returns>The amount due.</returns>
        public decimal GetAmountDue()
        {
            return Math.Round(GetTotal() - tradeInAmount, 2);
        }
    }
}