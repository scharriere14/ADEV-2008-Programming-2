﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 1
 * Created: 2023-09-02
 * Updated: 2023-09-21
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Wang.Ming.Business;

namespace Wang.Ming.RRCAG
{
    class Program
    {
        static void Main(string[] args)
        {
            TestSalesQuoteConstructor();
            TestSetTradeInAmount();
            TestGetExteriorFinishCost();
            TestGetTotal();
        }

        // Unit test for SalesQuote constructor
        static void TestSalesQuoteConstructor()
        {
            Console.WriteLine("\nTesting method SalesQuote(decimal, decimal, decimal)");

            // Test 1
            SalesQuote quote1 = new SalesQuote(5000.00M, 1000.00M, 0.12M);
            Console.WriteLine("\nTest 1");
            Console.WriteLine("Expected: 5000.00");
            Console.WriteLine("Actual: " + quote1.GetVehicleSalePrice().ToString("F2"));

            // Test 2
            SalesQuote quote2 = new SalesQuote(6000.00M, 2000.00M, 0.12M);
            Console.WriteLine("\nTest 2");
            Console.WriteLine("Expected: 6000.00");
            Console.WriteLine("Actual: " + quote2.GetVehicleSalePrice().ToString("F2"));
        }

        // Unit test for SetTradeInAmount method
        static void TestSetTradeInAmount()
        {
            Console.WriteLine("\n\nTesting method SetTradeInAmount(decimal)");

            // Test 1
            SalesQuote quote1 = new SalesQuote(5000.00M, 1000.00M, 0.12M);
            quote1.SetTradeInAmount(1500.00M);
            Console.WriteLine("\nTest 1");
            Console.WriteLine("Expected: 1500.00");
            Console.WriteLine("Actual: " + quote1.GetTradeInAmount().ToString("F2"));

            // Test 2
            SalesQuote quote2 = new SalesQuote(6000.00M, 2000.00M, 0.12M);
            quote2.SetTradeInAmount(2500.00M);
            Console.WriteLine("\nTest 2");
            Console.WriteLine("Expected: 2500.00");
            Console.WriteLine("Actual: " + quote2.GetTradeInAmount().ToString("F2"));
        }

        //Unit test for TestGetExteriorFinishCost method
        static void TestGetExteriorFinishCost()
        {
            Console.WriteLine("\n\nTesting method GetExteriorFinishCost()");

            // Test 1
            SalesQuote quote1 = new SalesQuote(20000M, 1000M, 0.10M, Accessories.None, ExteriorFinish.Standard);
            Console.WriteLine("\nTest 1");
            Console.WriteLine("Expected: 202.02");
            Console.WriteLine($"Actual: {quote1.GetExteriorFinishCost():0.00}");

            // Test 2
            SalesQuote quote2 = new SalesQuote(20000M, 1000M, 0.10M, Accessories.None, ExteriorFinish.Pearlized);
            Console.WriteLine("\nTest 2");
            Console.WriteLine("Expected: 404.04");
            Console.WriteLine($"Actual: {quote2.GetExteriorFinishCost():0.00}");
        }

        //Unit test for GetTotal method
        static void TestGetTotal()
        {
            Console.WriteLine("\n\nTesting method GetTotal()");

            // Test 1
            SalesQuote quote2 = new SalesQuote(25000M, 505.05M, 0.10M, Accessories.LeatherInterior, ExteriorFinish.Pearlized);
            Console.WriteLine("\nTest 1");
            Console.WriteLine("Expected: 29055.55");
            Console.WriteLine($"Actual: {quote2.GetTotal():0.00}\n");
        }
    }
}

