﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 6
 * Created: 2023-11-01
 * Updated: 2023-11-26
 */

using ACE.BIT.ADEV.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Wang.Ming.RRCAGApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            this.Text = "RRC Automotive Group";
            this.IsMdiContainer = true;
            this.WindowState = FormWindowState.Maximized;
        }

        private void salesQuoteCtrl1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Instantiate and show the Sales Quote Form as an MDI child
            Form salesQuoteForm = new SalesQuoteForm();
            salesQuoteForm.MdiParent = this;
            salesQuoteForm.Show();
        }

        private void carWashCtrl2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Instantiate and show the Car Wash Form as an MDI child
            Form carWashForm = new CarWashForm();
            carWashForm.MdiParent = this;
            carWashForm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Close the main form
            this.Close();
        }

        private Form vehicleDataFormInstance;
        private void vehiclesCtrlShiftVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Check if the Vehicle Data Form is already open
            if (vehicleDataFormInstance == null || vehicleDataFormInstance.IsDisposed)
            {
                vehicleDataFormInstance = new VehicleDataForm();
                vehicleDataFormInstance.MdiParent = this;
                vehicleDataFormInstance.Show();
            }
            else
            {
                // Bring the form to the front if already open
                vehicleDataFormInstance.Activate();
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutForm form;

            form = new AboutForm();

            form.ShowDialog();
        }

        private void mnuToolsGenerateInvoice_Click(object sender, EventArgs e)
        {
            CarWashInvoiceForm invoiceForm = new CarWashInvoiceForm();
            invoiceForm.Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
