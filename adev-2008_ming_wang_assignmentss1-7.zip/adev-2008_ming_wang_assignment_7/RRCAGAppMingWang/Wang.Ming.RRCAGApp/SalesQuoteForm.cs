﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 7
 * Created: 2023-12-01
 * Updated: 2023-12-12
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wang.Ming.Business;
using ACE.BIT.ADEV;

namespace Wang.Ming.RRCAGApp
{
    public partial class SalesQuoteForm : Form
    {
        private decimal provincialSalesTaxRate = 0.07M;
        private decimal goodsAndServicesTaxRate = 0.05M;
        private bool salesQuoteCreated = false;

        public SalesQuoteForm()
        {
            InitializeComponent();

            vehicleSalePriceTextBox.TextChanged += vehicleSalePriceTextBox_TextChanged;
            this.calculateQuoteButton.Click += this.calculateQuote_Click;
            stereoSystemCheckBox.CheckedChanged += AccessoriesOrFinishChanged;
            leatherInteriorCheckBox.CheckedChanged += AccessoriesOrFinishChanged;
            computerNavigationCheckBox.CheckedChanged += AccessoriesOrFinishChanged;
            financingYearsNumericUpDown.ValueChanged += FinancingValueChanged;
            annualInterestRateNumericUpDown.ValueChanged += FinancingValueChanged;
            standardFinishRadioButton.CheckedChanged += AccessoriesOrFinishChanged;
            pearlizedFinishRadioButton.CheckedChanged += AccessoriesOrFinishChanged;
            customFinishRadioButton.CheckedChanged += AccessoriesOrFinishChanged;

            this.Text = "Vehicle Sales Quote";
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            vehicleSalePriceTextBox.Text = string.Empty;
            tradeInValueTextBox.Text = "0";


            decimal totalSalesTaxRate = provincialSalesTaxRate + goodsAndServicesTaxRate;
            salesTaxLabel.Text = $"Sales Tax ({totalSalesTaxRate:P2})";

            financingYearsNumericUpDown.Value = 1;
            annualInterestRateNumericUpDown.Value = 5;

            this.AcceptButton = calculateQuoteButton;

            // Configure the Number of Years NumericUpDown
            this.financingYearsNumericUpDown.Minimum = 1;
            this.financingYearsNumericUpDown.Maximum = 10;
            this.financingYearsNumericUpDown.Increment = 1;
            this.financingYearsNumericUpDown.Value = 1; // Assuming you want the default to be 1

            // Configure the Annual Interest Rate NumericUpDown
            this.annualInterestRateNumericUpDown.DecimalPlaces = 2;
            this.annualInterestRateNumericUpDown.Minimum = 0;
            this.annualInterestRateNumericUpDown.Maximum = 25;
            this.annualInterestRateNumericUpDown.Increment = 0.25M;
            this.annualInterestRateNumericUpDown.Value = 5; // Assuming you want the default to be 5%
        }
      
        private void calculateQuote_Click(object sender, EventArgs e)
        {
            // Clear all previous errors.
            errorProvider1.Clear();

            bool hasError = false;
            decimal vehicleSalePrice = 0m;
            decimal tradeInValue = 0m;

            // Validate vehicle sale price
            if (string.IsNullOrWhiteSpace(vehicleSalePriceTextBox.Text))
            {
                errorProvider1.SetError(vehicleSalePriceTextBox, "Vehicle price is a required field.");
                hasError = true;
            }
            else if (!decimal.TryParse(vehicleSalePriceTextBox.Text, out vehicleSalePrice))
            {
                errorProvider1.SetError(vehicleSalePriceTextBox, "Vehicle price must be a numeric value.");
                hasError = true;
            }
            else if (vehicleSalePrice <= 0)
            {
                errorProvider1.SetError(vehicleSalePriceTextBox, "Vehicle price cannot be less than or equal to zero.");
                hasError = true;
            }

            // Validate trade-in value
            if (string.IsNullOrWhiteSpace(tradeInValueTextBox.Text))
            {
                errorProvider1.SetError(tradeInValueTextBox, "Trade-in value is a required field.");
                hasError = true;
            }
            else if (!decimal.TryParse(tradeInValueTextBox.Text, out tradeInValue))
            {
                errorProvider1.SetError(tradeInValueTextBox, "Trade-in value must be a numeric value.");
                hasError = true;
            }
            else if (tradeInValue < 0)
            {
                errorProvider1.SetError(tradeInValueTextBox, "Trade-in value cannot be less than zero.");
                hasError = true;
            }
            else if (tradeInValue > vehicleSalePrice)
            {
                errorProvider1.SetError(tradeInValueTextBox, "Trade-in value cannot exceed the vehicle sale price.");
                hasError = true;
            }

            // If no errors were found, proceed with calculation
            if (!hasError)
            {
                decimal optionsCost = CalculateOptionsCost();
                decimal subtotal = vehicleSalePrice + optionsCost;
                decimal salesTaxAmount = CalculateSalesTaxAmount(subtotal);
                decimal total = CalculateTotal(subtotal, salesTaxAmount);
                decimal amountDue = CalculateAmountDue(total, tradeInValue);
                decimal monthlyPayment = CalculateMonthlyPayment(amountDue, annualInterestRateNumericUpDown.Value, (int)financingYearsNumericUpDown.Value);

                // Update the UI with the sales quote summary
                vehicleSalePriceOutputBox.Text = vehicleSalePrice.ToString("C");
                optionsOutputBox.Text = optionsCost.ToString("N");
                subtotalOutputBox.Text = subtotal.ToString("C");
                salesTaxAmountOutputBox.Text = salesTaxAmount.ToString("N");
                totalOutputBox.Text = total.ToString("C");
                tradeInOutputBox.Text = (-tradeInValue).ToString("N");
                amountDueOutputBox.Text = amountDue.ToString("C");
                monthlyPaymentOutputBox.Text = monthlyPayment.ToString("C");

                salesQuoteCreated = true;
            }
        }

        private void vehicleSalePriceTextBox_TextChanged(object sender, EventArgs e)
        {
            vehicleSalePriceTextBox.Focus();
            salesQuoteCreated = false;
        }

       
        private decimal CalculateOptionsCost()
        {
            return GetAccessoryCost() + GetFinishCost();
        }

        private decimal CalculateSalesTaxAmount(decimal subtotal)
        {
            // Calculate sales tax based on subtotal
            return subtotal * (provincialSalesTaxRate + goodsAndServicesTaxRate);
        }

        private decimal CalculateTotal(decimal subtotal, decimal salesTax)
        {
            return subtotal + salesTax;
        }

        private decimal CalculateAmountDue(decimal total, decimal tradeInValue)
        {
            return total - tradeInValue;
        }

        private decimal CalculateMonthlyPayment(decimal amountDue, decimal annualInterestRate, int numberOfYears)
        {
            if (annualInterestRate == 0)
            {
                return amountDue / (numberOfYears * 12);
            }

            decimal monthlyInterestRate = annualInterestRate / 12 / 100;
            int numberOfPayments = numberOfYears * 12;
            decimal compoundedInterestRate = (decimal)Math.Pow(1 + (double)monthlyInterestRate, numberOfPayments);
            decimal interestQuotient = (monthlyInterestRate * compoundedInterestRate) / (compoundedInterestRate - 1);

            decimal monthlyPayment = amountDue * interestQuotient;
            return monthlyPayment;
        }

        private void AccessoriesOrFinishChanged(object sender, EventArgs e)
        {
            if (salesQuoteCreated)
            {
                UpdateQuoteSummaryAndMonthlyPayment();
            }
        }

        private void UpdateQuoteSummaryAndMonthlyPayment()
        {
            if (!salesQuoteCreated) return;


            decimal optionsCost = CalculateOptionsCost();

            // Recalculate the subtotal and other amounts.
            decimal vehicleSalePrice = decimal.Parse(vehicleSalePriceTextBox.Text);
            decimal tradeInValue = decimal.Parse(tradeInValueTextBox.Text);
            decimal subtotal = vehicleSalePrice + optionsCost;
            decimal salesTaxAmount = CalculateSalesTaxAmount(subtotal);
            decimal total = CalculateTotal(subtotal, salesTaxAmount);
            decimal amountDue = CalculateAmountDue(total, tradeInValue);
            decimal monthlyPayment = CalculateMonthlyPayment(
                amountDue,
                annualInterestRateNumericUpDown.Value,
                (int)financingYearsNumericUpDown.Value
            );

            // Update the UI with the new calculations.
            optionsOutputBox.Text = optionsCost.ToString("C");
            subtotalOutputBox.Text = subtotal.ToString("C");
            salesTaxAmountOutputBox.Text = salesTaxAmount.ToString("C");
            totalOutputBox.Text = total.ToString("C");
            tradeInOutputBox.Text = (-tradeInValue).ToString("C");
            amountDueOutputBox.Text = amountDue.ToString("C");
            monthlyPaymentOutputBox.Text = monthlyPayment.ToString("C");
        }

        private decimal GetAccessoryCost()
        {
            // Placeholder for the actual accessory cost calculation.
            decimal accessoryCost = 0m;
            if (stereoSystemCheckBox.Checked) accessoryCost += 505.05M;
            if (leatherInteriorCheckBox.Checked) accessoryCost += 1010.10M;
            if (computerNavigationCheckBox.Checked) accessoryCost += 1515.15M;
            return accessoryCost;
        }

        private decimal GetFinishCost()
        {
            // Cost for the finishes
            decimal standardFinishCost = 202.02M;
            decimal pearlizedFinishCost = 404.04M;
            decimal customFinishCost = 606.06M;

            if (standardFinishRadioButton.Checked)
                return standardFinishCost;
            else if (pearlizedFinishRadioButton.Checked)
                return pearlizedFinishCost;
            else if (customFinishRadioButton.Checked)
                return customFinishCost;

            // If none are selected, return 0
            return 0m;
        }


        private void FinancingValueChanged(object sender, EventArgs e)
        {
            if (salesQuoteCreated)
            {
                UpdateQuoteSummaryAndMonthlyPayment();
            }
        }


        private void resetBottom_Click(object sender, EventArgs e)
        {
            // Show the confirmation dialog
            DialogResult dialogResult = MessageBox.Show(
                "Do you want to reset the form?",
                "Reset Form",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2); // Button2 means "No" is the default

            // Check the result of the dialog
            if (dialogResult == DialogResult.Yes)
            {
                ResetForm();
            }
        }

        // Method to reset the form
        private void ResetForm()
        {
            // Reset the vehicle sale price and trade-in value
            vehicleSalePriceTextBox.Text = string.Empty;
            tradeInValueTextBox.Text = "0";

            // Reset the checkboxes for the accessories
            stereoSystemCheckBox.Checked = false;
            leatherInteriorCheckBox.Checked = false;
            computerNavigationCheckBox.Checked = false;

            // Uncheck all radio buttons for the finish
            standardFinishRadioButton.Checked = false;
            pearlizedFinishRadioButton.Checked = false;
            customFinishRadioButton.Checked = false;

            // Reset NumericUpDown controls
            financingYearsNumericUpDown.Value = financingYearsNumericUpDown.Minimum;
            annualInterestRateNumericUpDown.Value = 5;

            // Clear the output fields
            vehicleSalePriceOutputBox.Text = string.Empty;
            optionsOutputBox.Text = string.Empty;
            subtotalOutputBox.Text = string.Empty;
            salesTaxAmountOutputBox.Text = string.Empty;
            totalOutputBox.Text = string.Empty;
            tradeInOutputBox.Text = string.Empty;
            amountDueOutputBox.Text = string.Empty;
            monthlyPaymentOutputBox.Text = string.Empty;


            errorProvider1.Clear();

            salesQuoteCreated = false;
        }

        private void SalesQuoteForm_Load(object sender, EventArgs e)
        {

        }
    }
}
