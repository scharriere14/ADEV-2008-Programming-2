﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 7
 * Created: 2023-12-01
 * Updated: 2023-12-12
 */

using Wang.Ming.Business;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Net.NetworkInformation;
using ACE.BIT.ADEV.Forms;


namespace Wang.Ming.RRCAGApp
{
    
    public class CarWashForm : ACE.BIT.ADEV.Forms.CarWashForm
    {
        private List<CarWashPackage> carWashPackages;
        private BindingSource bindingSource;
        private List<Fragrance> fragrances;
        private BindingSource fragranceBindingSource;


        public CarWashForm()
        {
            InitializeComponent();
            // Initialize the list and the BindingSource.
            this.carWashPackages = new List<CarWashPackage>();

            // Initialize the fragrances list.
            this.fragrances = new List<Fragrance>();

            // Load fragrances from the file.
            LoadFragrancesFromFile();

            // Populate the car wash package list.
            this.carWashPackages.Add(new CarWashPackage("Standard", 7.50m));
            this.carWashPackages.Add(new CarWashPackage("Deluxe", 15.00m));
            this.carWashPackages.Add(new CarWashPackage("Executive", 35.00m));
            this.carWashPackages.Add(new CarWashPackage("Luxury", 55.00m));

            this.bindingSource = new BindingSource();
            this.fragranceBindingSource = new BindingSource();

            // Subscribe to the Load event of the form.
            this.Load += CustomCarWashForm_Load;
        }

        private void BindControls()
        {
            // Set the BindingSource DataSource.
            this.bindingSource.DataSource = this.carWashPackages;
            this.cboPackage.DataSource = this.bindingSource;
            this.cboPackage.DisplayMember = "Package";
            this.cboPackage.ValueMember = "Price";

            this.fragranceBindingSource.DataSource = this.fragrances;
            this.cboFragrance.DataSource = this.fragranceBindingSource;
            this.cboFragrance.DisplayMember = "Name";
            this.cboFragrance.ValueMember = "Price";
        }

        private void CustomCarWashForm_Load(object sender, EventArgs e)
        {
            // Bind data sources to ComboBox controls
            BindControls();

            // Set the default selected index for cboFragrance
            if (cboFragrance.Items.Count > 0)
            {
                cboFragrance.SelectedIndex = cboFragrance.FindStringExact("Pine");
            }

            // Ensure no package is selected by default
            this.cboPackage.SelectedIndex = -1;

            // Initialize pricing labels as blank
            ClearPricingLabels();

            // Clear and setup ListBoxes with default state
            lstExterior.Items.Clear();
            lstInterior.Items.Clear();

            // Disable menu items or buttons based on initial form state
            mnuToolsGenerateInvoice.Enabled = false;
        }

        private void ClearPricingLabels()
        {
            lblSubtotal.Text = "";
            lblGoodsAndServicesTax.Text = "";
            lblProvincialSalesTax.Text = "";
            lblTotal.Text = "";
        }

        public class CarWashPackage
        {
            public string Package { get; set; }
            public decimal Price { get; set; }

            public CarWashPackage(string Package, decimal price)
            {
                this.Package = Package;
                this.Price = price;
            }
        }

        public class Fragrance
        {
            public string Name { get; set; }
            public decimal Price { get; set; }

            public Fragrance(string name, decimal price)
            {
                this.Name = name;
                this.Price = price;
            }
        }

        private void LoadFragrancesFromFile()
        {
            string filepath = "fragrances.txt";

            if (!File.Exists(filepath))
            {
                MessageBox.Show("Fragrances data file not found.");
                return; // Exit the method if the file doesn't exist
            }

            try
            {
                var fragranceLines = File.ReadAllLines(filepath);

                foreach (var line in fragranceLines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 2)
                    {
                        this.fragrances.Add(new Fragrance(parts[0], decimal.Parse(parts[1])));
                    }
                }

                // Sort the fragrances list alphabetically.
                this.fragrances.Sort((f1, f2) => f1.Name.CompareTo(f2.Name));
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while reading the data file: " + ex.Message);
            }
        }
        private void cboPackage_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Ensure that an item is actually selected
            if (cboPackage.SelectedItem is CarWashPackage selectedPackage)
            {
                // Update the services list boxes
                UpdateServiceListBoxes(selectedPackage);

                // Update the pricing labels
                UpdatePricingLabels();
            }
            else
            {
                // Handle the case when no package is selected
                lstInterior.Items.Clear();
                lstExterior.Items.Clear();
                mnuToolsGenerateInvoice.Enabled = true;
            }
        }


        private void UpdateServiceListBoxes(CarWashPackage selectedPackage)
        {
            lstInterior.Items.Clear();
            lstExterior.Items.Clear();

            // Add "Fragrance" to all packages
            lstInterior.Items.Add("Fragrance - " + cboFragrance.Text); 

            // Add services based on the package selected
            switch (selectedPackage.Package)
            {
                case "Standard":
                    // Add standard services
                    lstExterior.Items.Add("Hand Wash");
                    break;
                case "Deluxe":
                    // Add deluxe services
                    lstInterior.Items.Add("Shampoo Carpets");
                    lstExterior.Items.Add("Hand Wash");
                    lstExterior.Items.Add("Hand Wax");
                    break;
                case "Executive":
                    // Add executive services
                    lstInterior.Items.Add("Shampoo Carpets");
                    lstInterior.Items.Add("Shampoo Upholstery");
                    lstExterior.Items.Add("Hand Wash");
                    lstExterior.Items.Add("Hand Wax");
                    lstExterior.Items.Add("Wheel Polish");
                    break;
                case "Luxury":
                    // Add luxury services
                    lstInterior.Items.Add("Shampoo Carpets");
                    lstInterior.Items.Add("Shampoo Upholstery");
                    lstInterior.Items.Add("Interior Protection Coat");
                    lstExterior.Items.Add("Hand Wash");
                    lstExterior.Items.Add("Hand Wax");
                    lstExterior.Items.Add("Wheel Polish");
                    lstExterior.Items.Add("Detail Engine Compartment");
                    break;
            }
        }

        private void UpdatePricingLabels()
        {
            var selectedPackage = cboPackage.SelectedItem as CarWashPackage;
            var selectedFragrance = cboFragrance.SelectedItem as Fragrance;

            if (selectedPackage != null && selectedFragrance != null)
            {
                decimal subtotal = selectedPackage.Price + (selectedFragrance.Name != "Pine" ? selectedFragrance.Price : 0m);
                decimal gst = CalculateGST(subtotal);
                decimal pst = CalculatePST(subtotal);
                decimal total = subtotal + gst + pst;

                lblSubtotal.Text = subtotal.ToString("C");
                lblGoodsAndServicesTax.Text = gst.ToString("C");
                lblProvincialSalesTax.Text = pst.ToString("C");
                lblTotal.Text = total.ToString("C");
            }
            else
            {
                // Clear the values when no package is selected
                ClearPricingLabels();
            }
        }

        private decimal CalculateGST(decimal subtotal)
        {
        
            return subtotal * 0.05m;
        }

        private decimal CalculatePST(decimal subtotal)
        {
            
            return subtotal * 0.07m;
        }

        private void cboFragrance_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Update the interior services ListBox with the selected fragrance
            UpdateInteriorServicesWithFragrance(cboFragrance.Text);

            // Update the pricing labels
            UpdatePricingLabels();
        }

        private void UpdateInteriorServicesWithFragrance(string fragranceName)
        {
            // Check if there are any items in the list and update the first one
            if (lstInterior.Items.Count > 0)
            {
                lstInterior.Items[0] = $"Fragrance - {fragranceName}";
            }
            else
            {
                // If the list is empty, just add the fragrance as the first item
                lstInterior.Items.Insert(0, $"Fragrance - {fragranceName}");
            }
        }

        private void mnuFileClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuToolsGenerateInvoice_Click(object sender, EventArgs e)
        {

            CarWashInvoiceForm carWashInvoiceForm = new CarWashInvoiceForm();
            carWashInvoiceForm.Show();
        }


        private void InitializeComponent()
        {
           // this.mnuFileClose = new System.Windows.Forms.ToolStripMenuItem();
           this.mnuToolsGenerateInvoice = new System.Windows.Forms.ToolStripMenuItem();

            this.SuspendLayout();
            // 
            // cboPackage
            // 
            this.cboPackage.SelectedIndexChanged += new System.EventHandler(this.cboPackage_SelectedIndexChanged);
            // 
            // cboFragrance
            // 
            this.cboFragrance.SelectedIndexChanged += new System.EventHandler(this.cboFragrance_SelectedIndexChanged);
            // 
            // lstExterior
            // 
            this.lstExterior.ItemHeight = 25;
            // 
            // lstInterior
            // 
            this.lstInterior.ItemHeight = 25;
            // 
            // mnuFileClose
            // 
            this.mnuFileClose.Name = "mnuFileClose";
            this.mnuFileClose.Size = new System.Drawing.Size(103, 22);
            this.mnuFileClose.Text = "Close";
            this.mnuFileClose.Click += new System.EventHandler(this.mnuFileClose_Click);
            // 
            // mnuToolsGenerateInvoice
            // 
            this.mnuToolsGenerateInvoice.Name = "mnuToolsGenerateInvoice";
            this.mnuToolsGenerateInvoice.Size = new System.Drawing.Size(32, 19);
            this.mnuToolsGenerateInvoice.Text = "Generate Invoice";
            this.mnuToolsGenerateInvoice.Click += new System.EventHandler(this.mnuToolsGenerateInvoice_Click);
            //
            // CarWashForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.ClientSize = new System.Drawing.Size(790, 825);
            this.Name = "CarWashForm";
            this.Text = "Car Wash";
            this.Load += new System.EventHandler(this.CustomCarWashForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
