﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 7
 * Created: 2023-12-01
 * Updated: 2023-12-12
 */

using System;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;


namespace Wang.Ming.RRCAGApp
{
    internal class VehicleDataForm : ACE.BIT.ADEV.Forms.VehicleDataForm
    {
        OleDbDataAdapter dataAdapter;
        DataSet dataSet;
        BindingSource bindingSource;

        //Constructor 
        public VehicleDataForm()
        {
            InitializeComponent();

            this.mnuFileClose.Click += MnuFileClose_Click;
            this.Load += VehicleDataForm_Load;
            this.dgvVehicles.AllowUserToDeleteRows = false;
            this.dgvVehicles.AllowUserToResizeRows = false;
            this.mnuEditRemove.Enabled = false;
            this.FormClosing += VehicleDataForm_FormClosing;
            this.dgvVehicles.SelectionChanged += DgvVehicles_SelectionChanged;
            this.dgvVehicles.CellValueChanged += DgvVehicles_CellValueChanged;
            this.mnuEditRemove.Click += MnuEditRemove_Click;
            this.mnuFileSave.Click += MnuFileSave_Click;
            mnuEditRemove.Enabled = false;

            VehicleDataFormLoad();
        }


        //selection change in DataGridView
        private void DgvVehicles_SelectionChanged(object sender, EventArgs e)
        {
            //Enable or disable edit/remove menu based on row
            if (dgvVehicles.CurrentRow != null && dgvVehicles.CurrentRow.Selected && !dgvVehicles.CurrentRow.IsNewRow)
            {
                mnuEditRemove.Enabled = true;
            }
            else
            {
                mnuEditRemove.Enabled = false;
            }
        }


        private void VehicleDataForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if data has changes
            if (dataSet.HasChanges())
            {
                DialogResult x = MessageBox.Show("Do you wish to save the changes?", 
                    "Save", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button3);

                if (x.Equals(DialogResult.Yes))
                {
                    try
                    {
                        SaveData();
                    }
                    catch (Exception)
                    {
                        DialogResult d = MessageBox.Show("An error occurred while saving. Do you still wish to close??",
                        "Save Error", MessageBoxButtons.YesNo, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2);

                        if (d.Equals(DialogResult.No))
                        {
                            e.Cancel = true;
                        }
                    }
                }
                else if (x.Equals(DialogResult.Cancel))
                {
                    e.Cancel = true;
                }

            }
        }

        private void VehicleDataFormLoad()
        {
            mnuFileSave.Enabled = false;

            //database connection
            OleDbConnection dbConnection = new OleDbConnection();
            dbConnection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=AMDatabase.mdb";
            dbConnection.Open();

            //db command
            OleDbCommand dbCommand = new OleDbCommand();
            dbCommand.Connection = dbConnection;
            dbCommand.CommandText = "SELECT * FROM VehicleStock";

            //Setting up data adapter and filling dataset.
            dataAdapter = new OleDbDataAdapter();
            dataAdapter.SelectCommand = dbCommand;
            OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder();
            commandBuilder.DataAdapter = dataAdapter;
            dataSet = new DataSet();
            dataAdapter.Fill(dataSet, "VehicleStock");

            //Connecting BindingSource object to data tables
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataSet.Tables["VehicleStock"];
            dgvVehicles.DataSource = bindingSource;
            dgvVehicles.Columns["ID"].Visible = false;
        }

        //cell value change
        private void DgvVehicles_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            this.Text = "* Vehicle Data";
            this.mnuFileSave.Enabled = true;
        }

        //save data
        private void SaveData()
        {
            dgvVehicles.EndEdit();
            bindingSource.EndEdit();
            mnuFileSave.Enabled = false;
            this.Text = "Vehicle Data";
            dataAdapter.Update(dataSet, "VehicleStock");
        }

        //load
        private void VehicleDataForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.VehicleDataFormLoad();
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to load vehicle data.", "Data Load Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                this.Close();
            }
        }



        //save menu item click
        private void MnuFileSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveData();
            }
            catch (Exception)
            {
                MessageBox.Show("An error occurred while saving the changes to the vehicle data.", 
                    "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //remove menu item click
        private void MnuEditRemove_Click(object sender, EventArgs e)
        {
            //display format
            string stockItem = this.dgvVehicles.CurrentRow.Cells["StockNumber"].Value.ToString();
            DialogResult result = MessageBox.Show(
                    "Remove stock item " + stockItem + " ?",
                    "Delete Stock Item",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2);

            if (result.Equals(DialogResult.Yes))
            {
                try
                {
                    dgvVehicles.Rows.Remove(dgvVehicles.SelectedRows[0]);
                }
                catch (Exception)
                {
                    MessageBox.Show("An error occurred when deleting the selected vehicle.", 
                        "Deletion Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                bindingSource.EndEdit();
                mnuEditRemove.Enabled = false;
            }
        }

       
        private void MnuFileClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // VehicleDataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(712, 421);
            this.Name = "VehicleDataForm";
            this.Text = "Vehicle Data";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.VehicleDataForm_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void VehicleDataForm_Load_1(object sender, EventArgs e)
        {

        }
    }
}
