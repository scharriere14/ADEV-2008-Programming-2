﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 7
 * Created: 2023-12-01
 * Updated: 2023-12-12
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wang.Ming.RRCAGApp
{
    public partial class CarWashInvoiceForm : Form
    {
   

        public CarWashInvoiceForm()
        {
            InitializeComponent();
        }

    

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void packagePriceBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void fragrancePriceBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void subtotalBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void pstBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void totalBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void CarWashInvoiceForm_Load(object sender, EventArgs e)
        {

        }
    }
}
