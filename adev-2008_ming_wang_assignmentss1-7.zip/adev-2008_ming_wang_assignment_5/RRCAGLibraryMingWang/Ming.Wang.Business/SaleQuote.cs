﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 5
 * Created: 2023-11-01
 * Updated: 2023-11-05
 */

using System;
using System.ComponentModel;

namespace Wang.Ming.Business
{
    /// <summary>
    /// Represents a sales quotation for a vehicle, including its price, accessories, and exterior finish.
    /// </summary>
    public class SalesQuote
    {
        private decimal vehicleSalePrice;
        private decimal tradeInAmount;
        private decimal salesTaxRate;
        private Accessories accessoriesChosen;
        private ExteriorFinish exteriorFinishChosen;

        /// <summary>
        /// Occurs when the sale price of the vehicle is modified.
        /// </summary>
        public event EventHandler VehiclePriceChanged;

        /// <summary>
        /// Occurs when the trade-in amount for the vehicle is changed.
        /// </summary>
        public event EventHandler TradeInAmountChanged;

        /// <summary>
        /// Occurs when a different set of accessories is selected for the vehicle.
        /// </summary>
        public event EventHandler AccessoriesChosenChanged;

        /// <summary>
        /// Occurs when a different exterior finish is selected for the vehicle.
        /// </summary>
        public event EventHandler ExteriorFinishChosenChanged;

        /// <summary>
        /// Raises the <see cref="VehiclePriceChanged"/> event.
        /// </summary>
        protected virtual void OnVehiclePriceChanged()
        {
            if (VehiclePriceChanged != null)
            {
                VehiclePriceChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Raises the <see cref="TradeInAmountChanged"/> event.
        /// </summary>
        protected virtual void OnTradeInAmountChanged()
        {
            if (TradeInAmountChanged != null)
            {
                TradeInAmountChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Raises the <see cref="AccessoriesChosenChanged"/> event.
        /// </summary>
        protected virtual void OnAccessoriesChosenChanged()
        {
            if (AccessoriesChosenChanged != null)
            {
                AccessoriesChosenChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Raises the <see cref="ExteriorFinishChosenChanged"/> event.
        /// </summary>
        protected virtual void OnExteriorFinishChosenChanged()
        {
            if (ExteriorFinishChosenChanged != null)
            {
                ExteriorFinishChosenChanged(this, new EventArgs());
            }
        }


        /// <summary>
        /// Gets or sets the sale price of the vehicle.
        /// </summary>
        /// <value>
        /// The sale price of the vehicle.
        /// </value>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the value is set to a number less than or equal to 0.
        /// </exception>
        public decimal VehicleSalePrice
        {
            get { return vehicleSalePrice; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than or equal to 0.");
                }
                if (vehicleSalePrice != value)
                {
                    vehicleSalePrice = value;
                    OnVehiclePriceChanged();
                }
            }
        }

        /// <summary>
        /// Gets or sets the trade-in amount for the vehicle.
        /// </summary>
        /// <value>
        /// The trade-in amount for the vehicle.
        /// </value>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the value is set to a number less than 0.
        /// </exception>
        public decimal TradeInAmount
        {
            get { return tradeInAmount; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                if (tradeInAmount != value)
                {
                    tradeInAmount = value;
                    OnTradeInAmountChanged();
                }
            }
        }

        /// <summary>
        /// Gets or sets the accessories chosen for the vehicle.
        /// </summary>
        /// <value>
        /// The accessories selected for the vehicle.
        /// </value>
        /// <exception cref="InvalidEnumArgumentException">
        /// Thrown when the value set does not belong to the <see cref="Accessories"/> enumeration.
        /// </exception>
        public Accessories AccessoriesChosen
        {
            get { return accessoriesChosen; }
            set
            {
                if (!Enum.IsDefined(typeof(Accessories), value))
                {
                    throw new InvalidEnumArgumentException("The value is an invalid enumeration value");
                }
                if (accessoriesChosen != value)
                {
                    accessoriesChosen = value;
                    OnAccessoriesChosenChanged();
                }
            }
        }

        /// <summary>
        /// Gets or sets the exterior finish chosen for the vehicle.
        /// </summary>
        /// <value>
        /// The exterior finish selected for the vehicle.
        /// </value>
        /// <exception cref="InvalidEnumArgumentException">
        /// Thrown when the value set does not belong to the <see cref="ExteriorFinish"/> enumeration.
        /// </exception>
        public ExteriorFinish ExteriorFinishChosen
        {
            get { return exteriorFinishChosen; }
            set
            {
                if (!Enum.IsDefined(typeof(ExteriorFinish), value))
                {
                    throw new InvalidEnumArgumentException("The value is an invalid enumeration value");
                }
                if (exteriorFinishChosen != value)
                {
                    exteriorFinishChosen = value;
                    OnExteriorFinishChosenChanged();
                }
            }
        }

        /// <summary>
        /// Gets the cost of the chosen accessories for the vehicle.
        /// </summary>
        public decimal AccessoryCost
        {
            get
            {
                return GetAccessoryCost(); 
            } 
        }

        /// <summary>
        /// Gets the cost of the chosen exterior finish for the vehicle.
        /// </summary>
        public decimal FinishCost
        {
            get
            {
                return GetFinishCost(); 
            }
        }

        /// <summary>
        /// Gets the total cost of options chosen for the vehicle.
        /// </summary>
        public decimal TotalOptions
        {
            get
            {
                return Math.Round(AccessoryCost + FinishCost, 2); 
            }
        }

        /// <summary>
        /// Gets the subtotal amount for the vehicle sale.
        /// </summary>
        public decimal SubTotal
        { 
            get
            { 
                return Math.Round(VehicleSalePrice + TotalOptions, 2); 
            } 
        }

        /// <summary>
        /// Gets the sales tax amount for the vehicle sale.
        /// </summary>
        public decimal SalesTax
        {
            get
            {
                return Math.Round(SubTotal * salesTaxRate, 2); 
            }
        }

        /// <summary>
        /// Gets the total amount due for the vehicle sale.
        /// </summary>
        public decimal Total
        {
            get
            {
                return SubTotal + SalesTax;
            }
        }

        /// <summary>
        /// Gets the amount due after considering the trade-in amount.
        /// </summary>
        public decimal AmountDue
        {
            get
            {
                return Math.Round(Total - TradeInAmount, 2); 
            } 
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SalesQuote"/> class with specific details.
        /// </summary>
        /// <param name="vehicleSalePrice">The sale price of the vehicle.</param>
        /// <param name="tradeInAmount">The trade-in amount for the vehicle.</param>
        /// <param name="salesTaxRate">The sales tax rate applicable to the sale.</param>
        /// <param name="accessoriesChosen">The accessories chosen for the vehicle.</param>
        /// <param name="exteriorFinishChosen">The exterior finish chosen for the vehicle.</param>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate, Accessories accessoriesChosen, ExteriorFinish exteriorFinishChosen)
        {
            ValidateInputs(vehicleSalePrice, tradeInAmount, salesTaxRate);

            VehicleSalePrice = vehicleSalePrice;
            TradeInAmount = tradeInAmount;
            this.salesTaxRate = salesTaxRate;
            AccessoriesChosen = accessoriesChosen;
            ExteriorFinishChosen = exteriorFinishChosen;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SalesQuote"/> class with default accessory and finish options.
        /// </summary>
        /// <param name="vehicleSalePrice">The sale price of the vehicle.</param>
        /// <param name="tradeInAmount">The trade-in amount for the vehicle.</param>
        /// <param name="salesTaxRate">The sales tax rate applicable to the sale.</param>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate)
        {
            ValidateInputs(vehicleSalePrice, tradeInAmount, salesTaxRate);

            VehicleSalePrice = vehicleSalePrice;
            TradeInAmount = tradeInAmount;
            this.salesTaxRate = salesTaxRate;
            AccessoriesChosen = Accessories.None;
            ExteriorFinishChosen = ExteriorFinish.None;
        }

        /// <summary>
        /// Validates the provided inputs for constructing a <see cref="SalesQuote"/>.
        /// </summary>
        /// <param name="vehicleSalePrice">The sale price of the vehicle.</param>
        /// <param name="tradeInAmount">The trade-in amount for the vehicle.</param>
        /// <param name="salesTaxRate">The sales tax rate applicable to the sale.</param>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Thrown when the vehicle sale price is less than or equal to 0, 
        /// the trade-in amount is less than 0, or 
        /// the sales tax rate is less than 0 or greater than 1.
        /// </exception>
        private void ValidateInputs(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate)
        {
            if (vehicleSalePrice <= 0)
            {
                throw new ArgumentOutOfRangeException("vehicleSalePrice", "The argument cannot be less than or equal to 0.");
            }
            if (tradeInAmount < 0)
            {
                throw new ArgumentOutOfRangeException("tradeInAmount", "The argument cannot be less than 0.");
            }
            if (salesTaxRate < 0)
            {
                throw new ArgumentOutOfRangeException("salesTaxRate", "The argument cannot be less than 0.");
            }
            if (salesTaxRate > 1)
            {
                throw new ArgumentOutOfRangeException("salesTaxRate", "The argument cannot be greater than 1.");
            }
        }


        /// <summary>
        /// Returns the cost of the chosen accessories.
        /// </summary>
        /// <returns>The cost of the chosen accessories.</returns>
        public decimal GetAccessoryCost()
        {
            decimal accessoriesCost = 0;
            decimal stereoSystem = 505.05M;
            decimal leatherInterior = 1010.10M;
            decimal computerNavigation = 1515.15M;

            switch (accessoriesChosen)
            {
                case Accessories.StereoSystem:
                    accessoriesCost = stereoSystem;
                    break;
                case Accessories.LeatherInterior:
                    accessoriesCost = leatherInterior;
                    break;
                case Accessories.ComputerNavigation:
                    accessoriesCost = computerNavigation;
                    break;
                case Accessories.StereoAndLeather:
                    accessoriesCost = stereoSystem + leatherInterior;
                    break;
                case Accessories.StereoAndNavigation:
                    accessoriesCost = stereoSystem + computerNavigation;
                    break;
                case Accessories.LeatherAndNavigation:
                    accessoriesCost = leatherInterior + computerNavigation;
                    break;
                case Accessories.All:
                    accessoriesCost = stereoSystem + leatherInterior + computerNavigation;
                    break;
                case Accessories.None:
                    accessoriesCost = 0;
                    break;
            }
            return accessoriesCost;
        }

        /// <summary>
        /// Returns the cost of the chosen exterior finish.
        /// </summary>
        /// <returns>The cost of the chosen exterior finish.</returns>
        public decimal GetFinishCost()
        {
            switch (exteriorFinishChosen)
            {
                case ExteriorFinish.Standard:
                    return 202.02M;
                case ExteriorFinish.Pearlized:
                    return 404.04M;
                case ExteriorFinish.Custom:
                    return 606.06M;
                default:
                    return 0M;
            }
        }
    }
}



