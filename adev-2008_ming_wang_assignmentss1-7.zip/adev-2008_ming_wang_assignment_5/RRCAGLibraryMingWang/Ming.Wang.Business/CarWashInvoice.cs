﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 5
 * Created: 2023-11-01
 * Updated: 2023-11-05
 */

using System;

namespace Wang.Ming.Business
{
    /// <summary>
    /// Represents an invoice for car wash services, including details on package and fragrance costs, as well as tax information.
    /// </summary>
    public class CarWashInvoice : Invoice
    {
        private decimal packageCost;
        private decimal fragranceCost;

        /// <summary>
        /// Occurs when the package cost changes.
        /// </summary>
        public event EventHandler PackageCostChanged;

        /// <summary>
        /// Occurs when the fragrance cost changes.
        /// </summary>
        public event EventHandler FragranceCostChanged;

        /// <summary>
        /// Raises the <see cref="PackageCostChanged"/> event.
        /// </summary>
        protected virtual void OnPackageCostChanged()
        {
            if (PackageCostChanged != null)
            {
                PackageCostChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Raises the <see cref="FragranceCostChanged"/> event.
        /// </summary>
        protected virtual void OnFragranceCostChanged()
        {
            if (FragranceCostChanged != null)
            {
                FragranceCostChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Gets or sets the cost of the car wash package. Raises the PackageCostChanged event if the value changes.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when the value is set to less than 0.</exception>
        public decimal PackageCost
        {
            get
            {
                return packageCost;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                if (value != packageCost)
                {
                    packageCost = value;
                    OnPackageCostChanged();
                }
            }
        }
        /// <summary>
        /// Gets or sets the cost of the fragrance service. Raises the FragranceCostChanged event if the value changes.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when the value is set to less than 0.</exception>
        public decimal FragranceCost
        {
            get
            {
                return fragranceCost;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "The value cannot be less than 0.");
                }
                if (value != fragranceCost)
                {
                    fragranceCost = value;
                    OnFragranceCostChanged();
                }
            }
        }

        /// <summary>
        /// Gets the provincial sales tax charged, which is always 0 for car wash services.
        /// </summary>
        public override decimal ProvincialSalesTaxCharged
        {
            get
            {
                return 0M;
            }
        }

        /// <summary>
        /// Gets the goods and services tax charged, calculated as the goods and services tax rate multiplied by the subtotal, rounded to 2 decimal places.
        /// </summary>
        public override decimal GoodsAndServicesTaxCharged
        {
            get
            {
                return Math.Round(GoodsAndServicesTaxRate * SubTotal, 2);
            }
        }

        /// <summary>
        /// Gets the subtotal of the invoice, calculated as the sum of the package cost and the fragrance cost.
        /// </summary>
        public override decimal SubTotal
        {
            get
            {
                return PackageCost + FragranceCost;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CarWashInvoice"/> class with specified provincial and goods and services tax rates, and zeroed package and fragrance costs.
        /// </summary>
        /// <param name="provincialSalesTaxRate">The rate of provincial sales tax.</param>
        /// <param name="goodsAndServicesTaxRate">The rate of goods and services tax.</param>
        public CarWashInvoice(decimal provincialSalesTaxRate, decimal goodsAndServicesTaxRate)
            : base(provincialSalesTaxRate, goodsAndServicesTaxRate)
        {
            packageCost = 0M;
            fragranceCost = 0M;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CarWashInvoice"/> class with specified provincial and goods and services tax rates, package cost, and fragrance cost.
        /// </summary>
        /// <param name="provincialSalesTaxRate">The rate of provincial sales tax.</param>
        /// <param name="goodsAndServicesTaxRate">The rate of goods and services tax.</param>
        /// <param name="packageCost">The cost of the chosen package.</param>
        /// <param name="fragranceCost">The cost of the chosen fragrance.</param>
        public CarWashInvoice(decimal provincialSalesTaxRate, decimal goodsAndServicesTaxRate, decimal packageCost, decimal fragranceCost)
            : base(provincialSalesTaxRate, goodsAndServicesTaxRate)
        {
            PackageCost = packageCost;
            FragranceCost = fragranceCost;
        }

    }
}

