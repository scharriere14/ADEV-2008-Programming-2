﻿namespace Wang.Ming.RRCAGApp
{
    partial class SalesQuoteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.vehicleSalePriceTextBox = new System.Windows.Forms.RichTextBox();
            this.tradeInValueTextBox = new System.Windows.Forms.RichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.computerNavigationCheckBox = new System.Windows.Forms.CheckBox();
            this.leatherInteriorCheckBox = new System.Windows.Forms.CheckBox();
            this.stereoSystemCheckBox = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.standardFinishRadioButton = new System.Windows.Forms.RadioButton();
            this.customFinishRadioButton = new System.Windows.Forms.RadioButton();
            this.pearlizedFinishRadioButton = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.resetBottom = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.optionsOutputBox = new System.Windows.Forms.RichTextBox();
            this.subtotalOutputBox = new System.Windows.Forms.RichTextBox();
            this.amountDueOutputBox = new System.Windows.Forms.RichTextBox();
            this.tradeInOutputBox = new System.Windows.Forms.RichTextBox();
            this.totalOutputBox = new System.Windows.Forms.RichTextBox();
            this.salesTaxAmountOutputBox = new System.Windows.Forms.RichTextBox();
            this.vehicleSalePriceOutputBox = new System.Windows.Forms.RichTextBox();
            this.amountDue = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Tradein = new System.Windows.Forms.Label();
            this.Total = new System.Windows.Forms.Label();
            this.salesTaxLabel = new System.Windows.Forms.Label();
            this.Subtotal = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.monthlyPaymentOutputBox = new System.Windows.Forms.RichTextBox();
            this.annualInterestRateNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.financingYearsNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.calculateQuoteButton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.annualInterestRateNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.financingYearsNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vehicle\'s Sale Price:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(98, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Trade-in Value:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // vehicleSalePriceTextBox
            // 
            this.vehicleSalePriceTextBox.Location = new System.Drawing.Point(263, 39);
            this.vehicleSalePriceTextBox.Name = "vehicleSalePriceTextBox";
            this.vehicleSalePriceTextBox.Size = new System.Drawing.Size(233, 37);
            this.vehicleSalePriceTextBox.TabIndex = 2;
            this.vehicleSalePriceTextBox.Text = "";
            this.vehicleSalePriceTextBox.TextChanged += new System.EventHandler(this.vehicleSalePriceTextBox_TextChanged);
            // 
            // tradeInValueTextBox
            // 
            this.tradeInValueTextBox.Location = new System.Drawing.Point(263, 101);
            this.tradeInValueTextBox.Name = "tradeInValueTextBox";
            this.tradeInValueTextBox.Size = new System.Drawing.Size(233, 37);
            this.tradeInValueTextBox.TabIndex = 3;
            this.tradeInValueTextBox.Text = "";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.computerNavigationCheckBox);
            this.panel1.Controls.Add(this.leatherInteriorCheckBox);
            this.panel1.Controls.Add(this.stereoSystemCheckBox);
            this.panel1.Location = new System.Drawing.Point(54, 185);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(442, 262);
            this.panel1.TabIndex = 5;
            // 
            // computerNavigationCheckBox
            // 
            this.computerNavigationCheckBox.AutoSize = true;
            this.computerNavigationCheckBox.Location = new System.Drawing.Point(22, 185);
            this.computerNavigationCheckBox.Name = "computerNavigationCheckBox";
            this.computerNavigationCheckBox.Size = new System.Drawing.Size(245, 29);
            this.computerNavigationCheckBox.TabIndex = 9;
            this.computerNavigationCheckBox.Text = "Computer Navigation";
            this.computerNavigationCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.computerNavigationCheckBox.UseVisualStyleBackColor = true;
            // 
            // leatherInteriorCheckBox
            // 
            this.leatherInteriorCheckBox.AutoSize = true;
            this.leatherInteriorCheckBox.Location = new System.Drawing.Point(22, 113);
            this.leatherInteriorCheckBox.Name = "leatherInteriorCheckBox";
            this.leatherInteriorCheckBox.Size = new System.Drawing.Size(189, 29);
            this.leatherInteriorCheckBox.TabIndex = 8;
            this.leatherInteriorCheckBox.Text = "Leather Interior";
            this.leatherInteriorCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.leatherInteriorCheckBox.UseVisualStyleBackColor = true;
            // 
            // stereoSystemCheckBox
            // 
            this.stereoSystemCheckBox.AutoSize = true;
            this.stereoSystemCheckBox.Location = new System.Drawing.Point(22, 38);
            this.stereoSystemCheckBox.Name = "stereoSystemCheckBox";
            this.stereoSystemCheckBox.Size = new System.Drawing.Size(184, 29);
            this.stereoSystemCheckBox.TabIndex = 7;
            this.stereoSystemCheckBox.Text = "Stereo System";
            this.stereoSystemCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.stereoSystemCheckBox.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Accessories";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.standardFinishRadioButton);
            this.panel3.Controls.Add(this.customFinishRadioButton);
            this.panel3.Controls.Add(this.pearlizedFinishRadioButton);
            this.panel3.Location = new System.Drawing.Point(54, 496);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(442, 262);
            this.panel3.TabIndex = 8;
            // 
            // standardFinishRadioButton
            // 
            this.standardFinishRadioButton.AutoSize = true;
            this.standardFinishRadioButton.Location = new System.Drawing.Point(22, 49);
            this.standardFinishRadioButton.Name = "standardFinishRadioButton";
            this.standardFinishRadioButton.Size = new System.Drawing.Size(130, 29);
            this.standardFinishRadioButton.TabIndex = 10;
            this.standardFinishRadioButton.TabStop = true;
            this.standardFinishRadioButton.Text = "Standard";
            this.standardFinishRadioButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.standardFinishRadioButton.UseVisualStyleBackColor = true;
            // 
            // customFinishRadioButton
            // 
            this.customFinishRadioButton.AutoSize = true;
            this.customFinishRadioButton.Location = new System.Drawing.Point(22, 181);
            this.customFinishRadioButton.Name = "customFinishRadioButton";
            this.customFinishRadioButton.Size = new System.Drawing.Size(246, 29);
            this.customFinishRadioButton.TabIndex = 12;
            this.customFinishRadioButton.TabStop = true;
            this.customFinishRadioButton.Text = "Customized Detailing";
            this.customFinishRadioButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.customFinishRadioButton.UseVisualStyleBackColor = true;
            // 
            // pearlizedFinishRadioButton
            // 
            this.pearlizedFinishRadioButton.AutoSize = true;
            this.pearlizedFinishRadioButton.Location = new System.Drawing.Point(22, 114);
            this.pearlizedFinishRadioButton.Name = "pearlizedFinishRadioButton";
            this.pearlizedFinishRadioButton.Size = new System.Drawing.Size(128, 29);
            this.pearlizedFinishRadioButton.TabIndex = 11;
            this.pearlizedFinishRadioButton.TabStop = true;
            this.pearlizedFinishRadioButton.Text = "Pearized";
            this.pearlizedFinishRadioButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.pearlizedFinishRadioButton.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(71, 480);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 25);
            this.label4.TabIndex = 9;
            this.label4.Text = "Extenior Finish";
            // 
            // resetBottom
            // 
            this.resetBottom.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.resetBottom.Location = new System.Drawing.Point(54, 812);
            this.resetBottom.Name = "resetBottom";
            this.resetBottom.Size = new System.Drawing.Size(152, 54);
            this.resetBottom.TabIndex = 10;
            this.resetBottom.Text = "Reset";
            this.resetBottom.UseVisualStyleBackColor = false;
            this.resetBottom.Click += new System.EventHandler(this.resetBottom_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(577, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Summary";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.optionsOutputBox);
            this.panel2.Controls.Add(this.subtotalOutputBox);
            this.panel2.Controls.Add(this.amountDueOutputBox);
            this.panel2.Controls.Add(this.tradeInOutputBox);
            this.panel2.Controls.Add(this.totalOutputBox);
            this.panel2.Controls.Add(this.salesTaxAmountOutputBox);
            this.panel2.Controls.Add(this.vehicleSalePriceOutputBox);
            this.panel2.Controls.Add(this.amountDue);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.Tradein);
            this.panel2.Controls.Add(this.Total);
            this.panel2.Controls.Add(this.salesTaxLabel);
            this.panel2.Controls.Add(this.Subtotal);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(562, 39);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(562, 510);
            this.panel2.TabIndex = 11;
            // 
            // optionsOutputBox
            // 
            this.optionsOutputBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.optionsOutputBox.Location = new System.Drawing.Point(274, 110);
            this.optionsOutputBox.Name = "optionsOutputBox";
            this.optionsOutputBox.ReadOnly = true;
            this.optionsOutputBox.Size = new System.Drawing.Size(233, 37);
            this.optionsOutputBox.TabIndex = 14;
            this.optionsOutputBox.Text = "";
            // 
            // subtotalOutputBox
            // 
            this.subtotalOutputBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.subtotalOutputBox.Location = new System.Drawing.Point(274, 172);
            this.subtotalOutputBox.Name = "subtotalOutputBox";
            this.subtotalOutputBox.ReadOnly = true;
            this.subtotalOutputBox.Size = new System.Drawing.Size(233, 37);
            this.subtotalOutputBox.TabIndex = 13;
            this.subtotalOutputBox.Text = "";
            // 
            // amountDueOutputBox
            // 
            this.amountDueOutputBox.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.amountDueOutputBox.Location = new System.Drawing.Point(274, 418);
            this.amountDueOutputBox.Name = "amountDueOutputBox";
            this.amountDueOutputBox.ReadOnly = true;
            this.amountDueOutputBox.Size = new System.Drawing.Size(233, 37);
            this.amountDueOutputBox.TabIndex = 12;
            this.amountDueOutputBox.Text = "";
            // 
            // tradeInOutputBox
            // 
            this.tradeInOutputBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tradeInOutputBox.Location = new System.Drawing.Point(274, 359);
            this.tradeInOutputBox.Name = "tradeInOutputBox";
            this.tradeInOutputBox.ReadOnly = true;
            this.tradeInOutputBox.Size = new System.Drawing.Size(233, 37);
            this.tradeInOutputBox.TabIndex = 11;
            this.tradeInOutputBox.Text = "";
            // 
            // totalOutputBox
            // 
            this.totalOutputBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.totalOutputBox.Location = new System.Drawing.Point(274, 297);
            this.totalOutputBox.Name = "totalOutputBox";
            this.totalOutputBox.ReadOnly = true;
            this.totalOutputBox.Size = new System.Drawing.Size(233, 37);
            this.totalOutputBox.TabIndex = 10;
            this.totalOutputBox.Text = "";
            // 
            // salesTaxAmountOutputBox
            // 
            this.salesTaxAmountOutputBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.salesTaxAmountOutputBox.Location = new System.Drawing.Point(274, 231);
            this.salesTaxAmountOutputBox.Name = "salesTaxAmountOutputBox";
            this.salesTaxAmountOutputBox.ReadOnly = true;
            this.salesTaxAmountOutputBox.Size = new System.Drawing.Size(233, 37);
            this.salesTaxAmountOutputBox.TabIndex = 9;
            this.salesTaxAmountOutputBox.Text = "";
            // 
            // vehicleSalePriceOutputBox
            // 
            this.vehicleSalePriceOutputBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.vehicleSalePriceOutputBox.Location = new System.Drawing.Point(274, 48);
            this.vehicleSalePriceOutputBox.Name = "vehicleSalePriceOutputBox";
            this.vehicleSalePriceOutputBox.ReadOnly = true;
            this.vehicleSalePriceOutputBox.Size = new System.Drawing.Size(233, 37);
            this.vehicleSalePriceOutputBox.TabIndex = 8;
            this.vehicleSalePriceOutputBox.Text = "";
            // 
            // amountDue
            // 
            this.amountDue.AutoSize = true;
            this.amountDue.Location = new System.Drawing.Point(115, 421);
            this.amountDue.Name = "amountDue";
            this.amountDue.Size = new System.Drawing.Size(136, 25);
            this.amountDue.TabIndex = 7;
            this.amountDue.Text = "Amount Due:";
            this.amountDue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(43, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(208, 25);
            this.label11.TabIndex = 6;
            this.label11.Text = "Vehicle\'s Sale Price:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Tradein
            // 
            this.Tradein.AutoSize = true;
            this.Tradein.Location = new System.Drawing.Point(153, 362);
            this.Tradein.Name = "Tradein";
            this.Tradein.Size = new System.Drawing.Size(98, 25);
            this.Tradein.TabIndex = 5;
            this.Tradein.Text = "Trade-in:";
            this.Tradein.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Total
            // 
            this.Total.AutoSize = true;
            this.Total.Location = new System.Drawing.Point(185, 300);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(66, 25);
            this.Total.TabIndex = 4;
            this.Total.Text = "Total:";
            this.Total.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // salesTaxLabel
            // 
            this.salesTaxLabel.AutoSize = true;
            this.salesTaxLabel.Location = new System.Drawing.Point(80, 234);
            this.salesTaxLabel.Name = "salesTaxLabel";
            this.salesTaxLabel.Size = new System.Drawing.Size(171, 25);
            this.salesTaxLabel.TabIndex = 3;
            this.salesTaxLabel.Text = "Sales Tax(12%):";
            this.salesTaxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Subtotal
            // 
            this.Subtotal.AutoSize = true;
            this.Subtotal.Location = new System.Drawing.Point(153, 175);
            this.Subtotal.Name = "Subtotal";
            this.Subtotal.Size = new System.Drawing.Size(97, 25);
            this.Subtotal.TabIndex = 2;
            this.Subtotal.Text = "Subtotal:";
            this.Subtotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(159, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 25);
            this.label6.TabIndex = 1;
            this.label6.Text = "Options:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.monthlyPaymentOutputBox);
            this.panel4.Controls.Add(this.annualInterestRateNumericUpDown);
            this.panel4.Controls.Add(this.financingYearsNumericUpDown);
            this.panel4.Location = new System.Drawing.Point(562, 582);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(562, 176);
            this.panel4.TabIndex = 13;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(358, 57);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(178, 25);
            this.label16.TabIndex = 15;
            this.label16.Text = "Monthly Payment";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(205, 32);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(134, 50);
            this.label14.TabIndex = 15;
            this.label14.Text = "Annual\r\nInterest Rate";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(43, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(132, 25);
            this.label15.TabIndex = 16;
            this.label15.Text = "No. of Years";
            // 
            // monthlyPaymentOutputBox
            // 
            this.monthlyPaymentOutputBox.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.monthlyPaymentOutputBox.Location = new System.Drawing.Point(362, 95);
            this.monthlyPaymentOutputBox.Name = "monthlyPaymentOutputBox";
            this.monthlyPaymentOutputBox.ReadOnly = true;
            this.monthlyPaymentOutputBox.Size = new System.Drawing.Size(174, 31);
            this.monthlyPaymentOutputBox.TabIndex = 13;
            this.monthlyPaymentOutputBox.Text = "";
            // 
            // annualInterestRateNumericUpDown
            // 
            this.annualInterestRateNumericUpDown.Location = new System.Drawing.Point(210, 95);
            this.annualInterestRateNumericUpDown.Name = "annualInterestRateNumericUpDown";
            this.annualInterestRateNumericUpDown.Size = new System.Drawing.Size(120, 31);
            this.annualInterestRateNumericUpDown.TabIndex = 1;
            // 
            // financingYearsNumericUpDown
            // 
            this.financingYearsNumericUpDown.Location = new System.Drawing.Point(48, 95);
            this.financingYearsNumericUpDown.Name = "financingYearsNumericUpDown";
            this.financingYearsNumericUpDown.Size = new System.Drawing.Size(120, 31);
            this.financingYearsNumericUpDown.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(577, 564);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 25);
            this.label13.TabIndex = 14;
            this.label13.Text = "Finance";
            // 
            // calculateQuoteButton
            // 
            this.calculateQuoteButton.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.calculateQuoteButton.Location = new System.Drawing.Point(925, 812);
            this.calculateQuoteButton.Name = "calculateQuoteButton";
            this.calculateQuoteButton.Size = new System.Drawing.Size(199, 54);
            this.calculateQuoteButton.TabIndex = 15;
            this.calculateQuoteButton.Text = "Calulate Quote";
            this.calculateQuoteButton.UseVisualStyleBackColor = false;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // SalesQuoteForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1166, 899);
            this.Controls.Add(this.calculateQuoteButton);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.resetBottom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tradeInValueTextBox);
            this.Controls.Add(this.vehicleSalePriceTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SalesQuoteForm";
            this.Text = "Vehicle Sales Quote";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.annualInterestRateNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.financingYearsNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox vehicleSalePriceTextBox;
        private System.Windows.Forms.RichTextBox tradeInValueTextBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox computerNavigationCheckBox;
        private System.Windows.Forms.CheckBox leatherInteriorCheckBox;
        private System.Windows.Forms.CheckBox stereoSystemCheckBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton standardFinishRadioButton;
        private System.Windows.Forms.RadioButton customFinishRadioButton;
        private System.Windows.Forms.RadioButton pearlizedFinishRadioButton;
        private System.Windows.Forms.Button resetBottom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label amountDue;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label Tradein;
        private System.Windows.Forms.Label Total;
        private System.Windows.Forms.Label salesTaxLabel;
        private System.Windows.Forms.Label Subtotal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox optionsOutputBox;
        private System.Windows.Forms.RichTextBox subtotalOutputBox;
        private System.Windows.Forms.RichTextBox amountDueOutputBox;
        private System.Windows.Forms.RichTextBox tradeInOutputBox;
        private System.Windows.Forms.RichTextBox totalOutputBox;
        private System.Windows.Forms.RichTextBox salesTaxAmountOutputBox;
        private System.Windows.Forms.RichTextBox vehicleSalePriceOutputBox;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RichTextBox monthlyPaymentOutputBox;
        private System.Windows.Forms.NumericUpDown annualInterestRateNumericUpDown;
        private System.Windows.Forms.NumericUpDown financingYearsNumericUpDown;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button calculateQuoteButton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}