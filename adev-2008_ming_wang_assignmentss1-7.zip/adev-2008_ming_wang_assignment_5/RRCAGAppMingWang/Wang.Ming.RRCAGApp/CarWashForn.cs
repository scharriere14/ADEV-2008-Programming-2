﻿/*
 * Name: Ming Wang
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Assignment 5
 * Created: 2023-11-01
 * Updated: 2023-11-05
 */

using ACE.BIT.ADEV.Forms;
using System.Windows.Forms;

namespace Wang.Ming.RRCAGApp
{
    
    public class CustomCarWashForm : CarWashForm
    {
        
        public CustomCarWashForm()
        {
            
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // cboPackage
            // 
            this.cboPackage.SelectedIndexChanged += new System.EventHandler(this.cboPackage_SelectedIndexChanged);
            // 
            // lstExterior
            // 
            this.lstExterior.ItemHeight = 25;
            this.lstExterior.SelectedIndexChanged += new System.EventHandler(this.lstExterior_SelectedIndexChanged);
            // 
            // lstInterior
            // 
            this.lstInterior.ItemHeight = 25;
            // 
            // CustomCarWashForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.ClientSize = new System.Drawing.Size(790, 825);
            this.Name = "CustomCarWashForm";
            this.Load += new System.EventHandler(this.CustomCarWashForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void CustomCarWashForm_Load(object sender, System.EventArgs e)
        {

        }

        private void cboPackage_SelectedIndexChanged(object sender, System.EventArgs e)
        {

        }

        private void lstExterior_SelectedIndexChanged(object sender, System.EventArgs e)
        {

        }
    }
}
